
import React from 'react';
import { Product, Category } from './types';

export const CATEGORIES: Category[] = [
  { id: 'diapers', name: 'الحفاضات', nameFr: 'Couches', icon: '🍼' },
  { id: 'feeding', name: 'الرضاعة والتغذية', nameFr: 'Alimentation', icon: '🍼' },
  { id: 'clothing', name: 'ملابس الرضع', nameFr: 'Vêtements', icon: '👕' },
  { id: 'toys', name: 'ألعاب تعليمية', nameFr: 'Jouets', icon: '🧸' },
  { id: 'care', name: 'العناية بالطفل', nameFr: 'Soins', icon: '🧴' },
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'حزمة حفاضات فاخرة 44 قطعة',
    nameFr: 'Pack de couches premium 44pcs',
    price: 120,
    category: 'diapers',
    image: 'https://picsum.photos/seed/baby1/400/400',
    description: 'حفاضات مريحة وناعمة على بشرة طفلك، توفر حماية تدوم حتى 12 ساعة.',
    descriptionFr: 'Couches confortables et douces pour la peau de votre bébé, offrant une protection jusqu\'à 12 heures.',
    ageRange: '0-6 months',
    stock: 15
  },
  {
    id: '2',
    name: 'طقم ملابس قطنية 3 قطع',
    nameFr: 'Ensemble en coton 3 pièces',
    price: 180,
    category: 'clothing',
    image: 'https://picsum.photos/seed/baby2/400/400',
    description: 'قطن 100% عالي الجودة لراحة طفلك اليومية.',
    descriptionFr: '100% coton de haute qualité pour le confort quotidien de votre bébé.',
    ageRange: '3-9 months',
    stock: 8
  },
  {
    id: '3',
    name: 'لعبة تعليمية خشبية منتسوري',
    nameFr: 'Jouet éducatif en bois Montessori',
    price: 250,
    category: 'toys',
    image: 'https://picsum.photos/seed/baby3/400/400',
    description: 'تساعد طفلك على تطوير مهاراته الحركية والذكاء.',
    descriptionFr: 'Aide votre bébé à développer sa motricité et son intelligence.',
    ageRange: '1-2 years',
    stock: 5
  },
  {
    id: '4',
    name: 'رضاعة مضادة للمغص 250 مل',
    nameFr: 'Biberon anti-colique 250ml',
    price: 95,
    category: 'feeding',
    image: 'https://picsum.photos/seed/baby4/400/400',
    description: 'تصميم مبتكر يمنع دخول الهواء لتقليل المغص والغازات.',
    descriptionFr: 'Design innovant empêchant l\'entrée d\'air pour réduire les coliques et les gaz.',
    ageRange: '0+ months',
    stock: 20
  },
  {
    id: '5',
    name: 'زيت التدليك العضوي للأطفال',
    nameFr: 'Huile de massage bio pour bébé',
    price: 110,
    category: 'care',
    image: 'https://picsum.photos/seed/baby5/400/400',
    description: 'مستخلصات طبيعية لتهدئة بشرة طفلك قبل النوم.',
    descriptionFr: 'Extraits naturels pour apaiser la peau de votre bébé avant le coucher.',
    ageRange: '0+ months',
    stock: 12
  },
  {
    id: '6',
    name: 'كرسي تغذية محمول',
    nameFr: 'Chaise haute portable',
    price: 450,
    category: 'feeding',
    image: 'https://picsum.photos/seed/baby6/400/400',
    description: 'خفيف الوزن وسهل التنظيف، مثالي للسفر والزيارات.',
    descriptionFr: 'Léger et facile à nettoyer, idéal pour les voyages et les visites.',
    ageRange: '6-24 months',
    stock: 3
  }
];
