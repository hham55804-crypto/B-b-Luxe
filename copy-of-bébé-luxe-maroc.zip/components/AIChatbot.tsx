
import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from './LanguageContext';
import { MessageSquare, Send, X, Bot, Sparkles } from 'lucide-react';
import { getBabyAdvice } from '../services/geminiService';

const AIChatbot: React.FC = () => {
  const { lang, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'bot'; text: string }[]>([
    { role: 'bot', text: lang === 'ar' ? 'مرحباً! أنا خبير Bébé Luxe. كيف أقدر نساعدك اليوم بخصوص طفلك؟' : 'Bonjour! Je suis l\'expert Bébé Luxe. Comment puis-je vous aider aujourd\'hui concernant votre bébé ?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const response = await getBabyAdvice(userMsg);
      setMessages(prev => [...prev, { role: 'bot', text: response || '...' }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'bot', text: 'Error contacting expert.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 z-50 bg-white border-2 border-[#F08080] text-[#F08080] p-4 rounded-full shadow-2xl hover:bg-[#FDE2E4] transition-all flex items-center gap-2"
      >
        <Sparkles size={24} className="animate-pulse" />
        <span className="font-bold text-sm hidden sm:inline">{t('chat_with_ai')}</span>
      </button>

      {isOpen && (
        <div className="fixed bottom-0 left-0 right-0 sm:bottom-24 sm:left-6 sm:right-auto z-[60] w-full sm:w-96 h-[500px] bg-white sm:rounded-3xl shadow-2xl flex flex-col border border-gray-100 overflow-hidden animate-in slide-in-from-bottom-5">
          <div className="bg-[#F08080] p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot size={24} />
              <div>
                <h3 className="font-bold leading-none">{t('chat_with_ai')}</h3>
                <span className="text-[10px] opacity-80">Powered by Gemini AI</span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)}><X size={20} /></button>
          </div>

          <div ref={scrollRef} className="flex-grow p-4 overflow-y-auto space-y-4 bg-gray-50">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                  m.role === 'user' ? 'bg-[#F08080] text-white rounded-br-none' : 'bg-white border border-gray-200 text-gray-700 rounded-bl-none shadow-sm'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 p-3 rounded-2xl rounded-bl-none shadow-sm">
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                    <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-white border-t border-gray-100 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder={lang === 'ar' ? 'طرح سؤالك هنا...' : 'Posez votre question ici...'}
              className="flex-grow px-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#F08080]"
            />
            <button
              onClick={handleSend}
              className="p-2 bg-[#F08080] text-white rounded-full hover:scale-105 transition-transform"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default AIChatbot;
