
import React, { useState } from 'react';
import { useLanguage } from './LanguageContext';
import { ShoppingBag, Menu, X, MessageCircle, Phone, Globe } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Layout: React.FC<{ children: React.ReactNode, cartCount: number }> = ({ children, cartCount }) => {
  const { lang, toggleLang, t } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: t('home'), path: '/' },
    { name: t('shop'), path: '/shop' },
    { name: t('about'), path: '/about' },
    { name: t('contact'), path: '/contact' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Banner */}
      <div className="bg-[#E2E2FF] text-[#4A4E69] text-center py-2 px-4 text-sm font-medium">
        ✨ {t('delivery')} | {t('cod')} ✅
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          {/* Mobile Menu Btn */}
          <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Logo */}
          <Link to="/" className="text-2xl font-bold font-brand text-[#F08080] flex items-center gap-2">
            <span className="bg-[#FDE2E4] p-2 rounded-full">👶</span>
            <span className="hidden sm:inline">Bébé Luxe</span>
          </Link>

          {/* Nav Links Desktop */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map(link => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium transition-colors ${
                  location.pathname === link.path ? 'text-[#F08080]' : 'text-gray-600 hover:text-[#F08080]'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <button
              onClick={toggleLang}
              className="flex items-center gap-1 text-xs font-bold uppercase border border-gray-200 px-3 py-1.5 rounded-full hover:bg-gray-50 transition-colors"
            >
              <Globe size={14} />
              {lang === 'ar' ? 'FR' : 'AR'}
            </button>
            <Link to="/checkout" className="relative p-2 bg-[#FDE2E4] rounded-full text-[#F08080] hover:scale-105 transition-transform">
              <ShoppingBag size={22} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full animate-bounce">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 p-4 space-y-4 shadow-xl">
            {navLinks.map(link => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsMenuOpen(false)}
                className="block text-lg font-medium text-gray-700"
              >
                {link.name}
              </Link>
            ))}
          </div>
        )}
      </header>

      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 py-12 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-xl font-bold font-brand text-[#F08080] mb-4">Bébé Luxe Maroc</h3>
            <p className="text-gray-500 max-w-sm leading-relaxed">
              {t('trust_title')}
            </p>
            <div className="mt-6 flex items-center gap-4">
              <span className="p-3 bg-[#E8F6EF] text-[#2D6A4F] rounded-2xl flex items-center gap-2">
                <Phone size={18} />
                +212 600-000000
              </span>
            </div>
          </div>
          <div>
            <h4 className="font-bold mb-4">{t('categories')}</h4>
            <ul className="space-y-2 text-gray-500 text-sm">
              <li>الحفاضات</li>
              <li>الرضاعة والتغذية</li>
              <li>ملابس الرضع</li>
              <li>العناية بالطفل</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">{t('shop')}</h4>
            <ul className="space-y-2 text-gray-500 text-sm">
              <li>{t('delivery')}</li>
              <li>{t('cod')}</li>
              <li>{t('whatsapp')}</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-gray-50 text-center text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} Bébé Luxe Maroc. All rights reserved.
        </div>
      </footer>

      {/* Floating WhatsApp */}
      <a
        href="https://wa.me/212600000000"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center gap-2 group"
      >
        <MessageCircle size={24} />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 font-medium whitespace-nowrap">
          {lang === 'ar' ? 'محتاج مساعدة؟' : 'Besoin d\'aide?'}
        </span>
      </a>
    </div>
  );
};

export default Layout;
