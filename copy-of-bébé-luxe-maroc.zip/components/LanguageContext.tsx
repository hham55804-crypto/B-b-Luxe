
import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  lang: Language;
  toggleLang: () => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<Language, Record<string, string>> = {
  ar: {
    home: 'الرئيسية',
    shop: 'المتجر',
    about: 'من نحن',
    contact: 'اتصل بنا',
    cod: 'الدفع عند الاستلام',
    delivery: 'توصيل لجميع مدن المغرب',
    whatsapp: 'تأكيد عبر الواتساب',
    buy_now: 'شري دابا',
    view_products: 'تفرج فالمنتجات',
    best_sellers: 'الأكثر مبيعا',
    categories: 'الأصناف',
    cart: 'السلة',
    checkout: 'إتمام الطلب',
    full_name: 'الاسم الكامل',
    phone: 'رقم الهاتف',
    city: 'المدينة',
    address: 'العنوان',
    confirm_order: 'طلب دابا والدفع عند التوصل',
    delivery_time: 'التوصيل 24–72 ساعة',
    trust_title: 'ثقة وسلامة طفلك هي أولويتنا',
    chat_with_ai: 'اسأل خبيرنا الآلي',
    limited_stock: 'كمية محدودة!',
    mad: 'درهم',
    order_success: 'تم تسجيل طلبك بنجاح! سنتصل بك قريبا.',
    edit_image: 'تعديل الصورة بالذكاء الاصطناعي',
  },
  fr: {
    home: 'Accueil',
    shop: 'Boutique',
    about: 'À propos',
    contact: 'Contact',
    cod: 'Paiement à la livraison',
    delivery: 'Livraison partout au Maroc',
    whatsapp: 'Confirmation via WhatsApp',
    buy_now: 'Acheter maintenant',
    view_products: 'Voir les produits',
    best_sellers: 'Meilleures ventes',
    categories: 'Catégories',
    cart: 'Panier',
    checkout: 'Caisse',
    full_name: 'Nom Complet',
    phone: 'Numéro de téléphone',
    city: 'Ville',
    address: 'Adresse',
    confirm_order: 'Commander et payer à la réception',
    delivery_time: 'Livraison 24–72 heures',
    trust_title: 'Confiance et sécurité pour votre bébé',
    chat_with_ai: 'Demandez à notre expert AI',
    limited_stock: 'Quantité limitée !',
    mad: 'DH',
    order_success: 'Votre commande a été enregistrée ! Nous vous appellerons bientôt.',
    edit_image: 'Modifier avec l\'IA',
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [lang, setLang] = useState<Language>('ar');

  const toggleLang = () => {
    const newLang = lang === 'ar' ? 'fr' : 'ar';
    setLang(newLang);
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = newLang;
  };

  const t = (key: string) => translations[lang][key] || key;

  return (
    <LanguageContext.Provider value={{ lang, toggleLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};
