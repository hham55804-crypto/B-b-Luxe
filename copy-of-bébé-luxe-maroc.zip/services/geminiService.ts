
import { GoogleGenAI, Type, GenerateContentResponse, Modality } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getBabyAdvice = async (message: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: message,
    config: {
      systemInstruction: "You are an expert pediatric consultant and parenting guide for Moroccan parents. Respond in Darija (Moroccan Arabic) or French as requested. Focus on baby safety, nutrition, and well-being. Be warm, reassuring, and helpful.",
      thinkingConfig: { thinkingBudget: 32768 }
    },
  });
  return response.text;
};

export const searchBabyTrends = async (query: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: query,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });
  
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  return {
    text: response.text,
    sources
  };
};

export const editProductImage = async (base64Image: string, prompt: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image.split(',')[1],
            mimeType: 'image/jpeg',
          },
        },
        { text: prompt },
      ],
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};

export const fastChat = async (message: string) => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-lite-latest",
      contents: message,
    });
    return response.text;
};
