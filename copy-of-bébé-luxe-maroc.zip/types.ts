
export interface Product {
  id: string;
  name: string;
  nameFr: string;
  price: number;
  category: string;
  image: string;
  description: string;
  descriptionFr: string;
  ageRange: string;
  stock: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export type Language = 'ar' | 'fr';

export interface Category {
  id: string;
  name: string;
  nameFr: string;
  icon: string;
}
