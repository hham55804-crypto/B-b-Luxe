
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '../components/LanguageContext';
import { PRODUCTS } from '../constants';
import { Truck, ShieldCheck, Wallet, ChevronRight, ChevronLeft, Plus, Minus, Wand2, Sparkles, Loader2 } from 'lucide-react';
import { editProductImage } from '../services/geminiService';

const ProductDetail: React.FC<{ addToCart: (id: string, qty: number) => void }> = ({ addToCart }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { lang, t } = useLanguage();
  const [quantity, setQuantity] = useState(1);
  const [editingImage, setEditingImage] = useState(false);
  const [editPrompt, setEditPrompt] = useState('');
  const [currentImage, setCurrentImage] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const product = PRODUCTS.find(p => p.id === id);

  useEffect(() => {
    if (product) setCurrentImage(product.image);
  }, [product]);

  if (!product) return <div className="p-20 text-center">Product not found</div>;

  const handleEditImage = async () => {
    if (!editPrompt.trim()) return;
    setIsEditing(true);
    try {
      // For demo purposes, we send the original image URL. Gemini 2.5 Flash Image will process it.
      const edited = await editProductImage(currentImage, editPrompt);
      if (edited) setCurrentImage(edited);
      setEditingImage(false);
      setEditPrompt('');
    } catch (error) {
      console.error(error);
    } finally {
      setIsEditing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-400 hover:text-[#F08080] mb-8 transition-colors">
        {lang === 'ar' ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        {lang === 'ar' ? 'الرجوع للمتجر' : 'Retour à la boutique'}
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Product Images */}
        <div className="space-y-6">
          <div className="relative rounded-3xl overflow-hidden bg-white shadow-lg border border-gray-100 aspect-square group">
            <img src={currentImage} alt={product.name} className="w-full h-full object-cover" />
            
            <button
              onClick={() => setEditingImage(true)}
              className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-md text-[#F08080] p-4 rounded-full shadow-xl hover:scale-110 transition-transform flex items-center gap-2 font-bold text-sm"
            >
              <Wand2 size={18} />
              {t('edit_image')}
            </button>
          </div>

          {editingImage && (
            <div className="bg-[#E2E2FF] p-6 rounded-3xl animate-in zoom-in-95 duration-200">
              <div className="flex items-center gap-2 mb-4 text-[#4A4E69]">
                <Sparkles size={18} />
                <h4 className="font-bold">{lang === 'ar' ? 'تعديل الصورة بالذكاء الاصطناعي' : 'Édition IA de l\'image'}</h4>
              </div>
              <p className="text-xs text-[#4A4E69]/70 mb-4">
                {lang === 'ar' ? 'اكتب شنو بغيتي تبدل، مثلا: "دير فلتر قديم" أو "زيد لعابة حدا الكرتونة"' : 'Décrivez les modifications souhaitées, ex: "Ajouter un filtre rétro"'}
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={editPrompt}
                  onChange={(e) => setEditPrompt(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثلا: زيد خلفية وردية' : 'Ex: ajouter un fond rose'}
                  className="flex-grow px-4 py-2 rounded-xl border-none focus:ring-2 focus:ring-[#F08080] outline-none text-sm"
                />
                <button
                  onClick={handleEditImage}
                  disabled={isEditing}
                  className="bg-[#F08080] text-white px-4 py-2 rounded-xl font-bold text-sm hover:scale-105 transition-transform flex items-center gap-2"
                >
                  {isEditing ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />}
                  {lang === 'ar' ? 'تطبيق' : 'Appliquer'}
                </button>
              </div>
              <button onClick={() => setEditingImage(false)} className="text-[10px] mt-2 text-[#4A4E69] hover:underline">إلغاء</button>
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          <span className="inline-block bg-[#FDE2E4] text-[#F08080] px-4 py-1 rounded-full text-xs font-bold w-fit mb-4">
            {lang === 'ar' ? 'متوفر حالياً' : 'En stock'}
          </span>
          <h1 className="text-4xl font-bold font-brand mb-4">{lang === 'ar' ? product.name : product.nameFr}</h1>
          <div className="flex items-center gap-4 mb-6">
            <span className="text-3xl font-bold text-[#F08080]">{product.price} {t('mad')}</span>
            <span className="text-gray-400 line-through text-lg">{product.price + 50} {t('mad')}</span>
          </div>

          <p className="text-gray-600 leading-relaxed mb-8 text-lg">
            {lang === 'ar' ? product.description : product.descriptionFr}
          </p>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="p-4 bg-gray-50 rounded-2xl flex items-center gap-3">
              <Truck size={20} className="text-blue-500" />
              <span className="text-xs font-medium">{t('delivery_time')}</span>
            </div>
            <div className="p-4 bg-gray-50 rounded-2xl flex items-center gap-3">
              <Wallet size={20} className="text-green-500" />
              <span className="text-xs font-medium">{t('cod')}</span>
            </div>
            <div className="p-4 bg-gray-50 rounded-2xl flex items-center gap-3">
              <ShieldCheck size={20} className="text-[#F08080]" />
              <span className="text-xs font-medium">{lang === 'ar' ? 'ضمان الجودة' : 'Qualité garantie'}</span>
            </div>
          </div>

          <div className="mt-auto space-y-4">
            <div className="flex items-center gap-6">
              <div className="flex items-center bg-gray-100 rounded-full px-4 py-2">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="p-1 hover:text-[#F08080]"><Minus size={18} /></button>
                <span className="mx-4 font-bold w-8 text-center">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)} className="p-1 hover:text-[#F08080]"><Plus size={18} /></button>
              </div>
              <div className="text-gray-400 text-sm">{lang === 'ar' ? 'الكمية المختارة' : 'Quantité sélectionnée'}</div>
            </div>

            <button
              onClick={() => {
                addToCart(product.id, quantity);
                navigate('/checkout');
              }}
              className="w-full bg-[#F08080] hover:bg-[#e06b6b] text-white py-5 rounded-3xl font-bold text-xl shadow-2xl hover:scale-[1.02] transition-all"
            >
              {t('confirm_order')}
            </button>
            <p className="text-center text-xs text-gray-400">
              {lang === 'ar' ? 'سيتصل بكم فريقنا لتأكيد الطلب قبل الإرسال' : 'Notre équipe vous contactera pour confirmer avant l\'envoi'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
