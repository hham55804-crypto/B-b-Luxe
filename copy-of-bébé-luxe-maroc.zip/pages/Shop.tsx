
import React, { useState, useMemo } from 'react';
import { useLanguage } from '../components/LanguageContext';
import { PRODUCTS, CATEGORIES } from '../constants';
import { Search, Filter, SlidersHorizontal, Star } from 'lucide-react';
import { Link } from 'react-router-dom';

const Shop: React.FC = () => {
  const { lang, t } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'low' | 'high' | 'newest'>('newest');

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.nameFr.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCat && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'low') return a.price - b.price;
      if (sortBy === 'high') return b.price - a.price;
      return 0;
    });
  }, [selectedCategory, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-bold font-brand mb-2">{t('shop')}</h1>
          <p className="text-gray-500">{filteredProducts.length} {lang === 'ar' ? 'منتجات متوفرة' : 'produits disponibles'}</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder={lang === 'ar' ? 'ابحث عن منتج...' : 'Chercher un produit...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-2xl w-full sm:w-64 focus:ring-2 focus:ring-[#F08080] outline-none"
            />
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-4 py-3 bg-white border border-gray-200 rounded-2xl outline-none"
          >
            <option value="newest">{lang === 'ar' ? 'الأحدث' : 'Plus récent'}</option>
            <option value="low">{lang === 'ar' ? 'الثمن: من الأقل' : 'Prix: Croissant'}</option>
            <option value="high">{lang === 'ar' ? 'الثمن: من الأعلى' : 'Prix: Décroissant'}</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-12">
        {/* Filters Sidebar */}
        <aside className="w-full lg:w-64 flex-shrink-0 space-y-8">
          <div>
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Filter size={18} />
              {t('categories')}
            </h3>
            <div className="flex flex-wrap lg:flex-col gap-2">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  selectedCategory === 'all' ? 'bg-[#F08080] text-white' : 'bg-white border border-gray-100 hover:bg-gray-50'
                }`}
              >
                {lang === 'ar' ? 'الكل' : 'Tous'}
              </button>
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                    selectedCategory === cat.id ? 'bg-[#F08080] text-white' : 'bg-white border border-gray-100 hover:bg-gray-50'
                  }`}
                >
                  {lang === 'ar' ? cat.name : cat.nameFr}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-[#E2E2FF] p-6 rounded-3xl">
            <h4 className="font-bold mb-2">{t('cod')}</h4>
            <p className="text-xs text-[#4A4E69] leading-relaxed">
              {lang === 'ar' ? 'جميع الطلبيات يتم الدفع عند استلامها من طرف الموزع.' : 'Toutes les commandes sont payables à la livraison auprès du livreur.'}
            </p>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-grow">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map(product => (
                <Link to={`/product/${product.id}`} key={product.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all group">
                  <div className="relative aspect-square overflow-hidden">
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  </div>
                  <div className="p-6">
                    <span className="text-[10px] uppercase tracking-widest text-gray-400 font-bold mb-1 block">
                      {CATEGORIES.find(c => c.id === product.category)?.nameFr}
                    </span>
                    <h3 className="font-bold text-lg mb-2 line-clamp-1">{lang === 'ar' ? product.name : product.nameFr}</h3>
                    <div className="flex items-center gap-1 mb-4">
                      {[1, 2, 3, 4, 5].map(s => <Star key={s} size={12} className="fill-yellow-400 text-yellow-400" />)}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#F08080] font-bold text-xl">{product.price} {t('mad')}</span>
                      <span className="text-xs text-green-600 font-bold bg-green-50 px-2 py-1 rounded">Stock OK</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-gray-50 rounded-3xl">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-bold text-gray-400">{lang === 'ar' ? 'لم نجد أي منتج يطابق بحثك' : 'Aucun produit trouvé'}</h3>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Shop;
