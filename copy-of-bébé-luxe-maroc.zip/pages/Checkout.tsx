
import React, { useState } from 'react';
import { useLanguage } from '../components/LanguageContext';
import { CartItem } from '../types';
import { Trash2, ShoppingBag, CreditCard, Truck, Phone, MapPin, User, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CheckoutProps {
  cart: CartItem[];
  removeFromCart: (id: string) => void;
  clearCart: () => void;
}

const Checkout: React.FC<CheckoutProps> = ({ cart, removeFromCart, clearCart }) => {
  const { lang, t } = useLanguage();
  const [formData, setFormData] = useState({ name: '', phone: '', city: '', address: '' });
  const [isSuccess, setIsSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const shipping = total > 0 ? 30 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      clearCart();
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="max-w-xl mx-auto px-4 py-32 text-center">
        <div className="inline-block p-6 bg-green-100 text-green-600 rounded-full mb-8">
          <CheckCircle2 size={64} />
        </div>
        <h1 className="text-4xl font-bold font-brand mb-4">{t('order_success')}</h1>
        <p className="text-gray-500 mb-8 leading-relaxed">
          {lang === 'ar' ? 'شكراً لثقتكم في بيبي لوكس. لقد توصلنا بطلبكم، وسيقوم أحد موظفينا بالاتصال بكم عبر الهاتف في غضون الساعات القليلة القادمة لتأكيد العنوان وموعد التسليم.' : 'Merci de votre confiance. Nous avons reçu votre commande. Un conseiller vous appellera dans les prochaines heures pour confirmer.'}
        </p>
        <Link to="/" className="bg-[#F08080] text-white px-10 py-4 rounded-full font-bold shadow-xl inline-block hover:scale-105 transition-transform">
          {lang === 'ar' ? 'الرجوع للرئيسية' : 'Retour à l\'accueil'}
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold font-brand mb-12 text-center">{t('checkout')}</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Cart Summary */}
        <div className="space-y-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <ShoppingBag className="text-[#F08080]" />
              {t('cart')}
            </h2>
            
            {cart.length === 0 ? (
              <div className="py-12 text-center text-gray-400">
                <p>{lang === 'ar' ? 'سلة التسوق فارغة' : 'Le panier est vide'}</p>
                <Link to="/shop" className="text-[#F08080] font-bold mt-4 inline-block hover:underline">{t('view_products')}</Link>
              </div>
            ) : (
              <div className="space-y-6">
                {cart.map(item => (
                  <div key={item.id} className="flex gap-4 items-center">
                    <img src={item.image} alt={item.name} className="w-20 h-20 rounded-2xl object-cover" />
                    <div className="flex-grow">
                      <h3 className="font-bold text-sm">{lang === 'ar' ? item.name : item.nameFr}</h3>
                      <p className="text-xs text-gray-400">x{item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-[#F08080]">{item.price * item.quantity} {t('mad')}</p>
                      <button onClick={() => removeFromCart(item.id)} className="text-gray-300 hover:text-red-500 transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-8 pt-8 border-t border-gray-100 space-y-4">
              <div className="flex justify-between text-gray-500">
                <span>{lang === 'ar' ? 'المجموع الفرعي' : 'Sous-total'}</span>
                <span>{total} {t('mad')}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>{lang === 'ar' ? 'توصيل' : 'Livraison'}</span>
                <span>{shipping} {t('mad')}</span>
              </div>
              <div className="flex justify-between text-xl font-bold pt-4">
                <span>{lang === 'ar' ? 'المجموع الكلي' : 'Total'}</span>
                <span className="text-[#F08080]">{total + shipping} {t('mad')}</span>
              </div>
            </div>
          </div>

          <div className="bg-[#E8F6EF] p-8 rounded-3xl flex items-center gap-6">
            <div className="p-4 bg-white rounded-2xl text-[#2D6A4F]">
              <CreditCard size={32} />
            </div>
            <div>
              <h3 className="font-bold text-[#2D6A4F] text-lg">{t('cod')}</h3>
              <p className="text-[#2D6A4F]/70 text-sm">
                {lang === 'ar' ? 'ما تخلص حتى توصلك الأمانة للباب وتاكد منها.' : 'Payez seulement à la réception de votre colis.'}
              </p>
            </div>
          </div>
        </div>

        {/* Checkout Form */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 h-fit">
          <h2 className="text-2xl font-bold mb-8">{lang === 'ar' ? 'معلومات التوصيل' : 'Informations de livraison'}</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-600 flex items-center gap-2">
                <User size={16} /> {t('full_name')}
              </label>
              <input
                required
                type="text"
                placeholder={lang === 'ar' ? 'الاسم والنسب' : 'Votre nom complet'}
                className="w-full px-5 py-4 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-[#F08080] outline-none"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-600 flex items-center gap-2">
                <Phone size={16} /> {t('phone')}
              </label>
              <input
                required
                type="tel"
                placeholder="06 -- -- -- --"
                className="w-full px-5 py-4 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-[#F08080] outline-none"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-600 flex items-center gap-2">
                  <MapPin size={16} /> {t('city')}
                </label>
                <input
                  required
                  type="text"
                  placeholder={lang === 'ar' ? 'المدينة' : 'Ville'}
                  className="w-full px-5 py-4 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-[#F08080] outline-none"
                  value={formData.city}
                  onChange={e => setFormData({ ...formData, city: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-600 flex items-center gap-2">
                  <Truck size={16} /> {t('address')}
                </label>
                <input
                  required
                  type="text"
                  placeholder={lang === 'ar' ? 'العنوان بالتفصيل' : 'Adresse exacte'}
                  className="w-full px-5 py-4 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-[#F08080] outline-none"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                />
              </div>
            </div>

            <button
              disabled={isSubmitting || cart.length === 0}
              type="submit"
              className="w-full bg-[#F08080] hover:bg-[#e06b6b] disabled:bg-gray-200 text-white py-5 rounded-3xl font-bold text-xl shadow-2xl hover:scale-[1.02] transition-all mt-8"
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center gap-3">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  {lang === 'ar' ? 'جاري الطلب...' : 'Traitement...'}
                </div>
              ) : t('confirm_order')}
            </button>
            <p className="text-center text-xs text-gray-400">
              🔒 {lang === 'ar' ? 'بياناتكم في أمان. سيتم الاتصال بكم للتأكيد.' : 'Vos données sont sécurisées. Nous vous rappellerons.'}
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
