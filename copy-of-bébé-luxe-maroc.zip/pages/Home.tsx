
import React from 'react';
import { useLanguage } from '../components/LanguageContext';
import { Link } from 'react-router-dom';
import { CATEGORIES, PRODUCTS } from '../constants';
import { CheckCircle, Truck, PhoneCall, ChevronLeft, ChevronRight, Star } from 'lucide-react';

const Home: React.FC = () => {
  const { lang, t } = useLanguage();

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] overflow-hidden flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src="https://picsum.photos/seed/baby-home/1600/900"
            className="w-full h-full object-cover brightness-75"
            alt="Baby background"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-white">
          <h1 className="text-4xl md:text-6xl font-bold font-brand mb-6 leading-tight max-w-2xl">
            {lang === 'ar' ? 'أفضل ما يستحقه طفلك من الحب والأمان' : 'Le meilleur pour l\'amour et la sécurité de votre bébé'}
          </h1>
          <p className="text-xl mb-8 text-gray-100 max-w-xl">
            {lang === 'ar' ? 'نحن نهتم بأدق التفاصيل لنضمن لطفلك راحة وسعادة تدوم طويلاً.' : 'Nous soignons chaque détail pour garantir à votre bébé un confort et un bonheur durables.'}
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              to="/shop"
              className="bg-[#F08080] hover:bg-[#e06b6b] text-white px-10 py-4 rounded-full font-bold text-lg shadow-xl hover:scale-105 transition-all"
            >
              {t('buy_now')}
            </Link>
            <Link
              to="/shop"
              className="bg-white/20 backdrop-blur-md hover:bg-white/30 text-white border border-white/50 px-10 py-4 rounded-full font-bold text-lg transition-all"
            >
              {t('view_products')}
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Highlights */}
      <section className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { icon: <CheckCircle className="text-green-500" size={32} />, title: t('cod'), desc: lang === 'ar' ? 'خلص فاش توصلك لمانتة' : 'Payez à la réception' },
          { icon: <Truck className="text-blue-500" size={32} />, title: t('delivery'), desc: t('delivery_time') },
          { icon: <PhoneCall className="text-[#F08080]" size={32} />, title: t('whatsapp'), desc: lang === 'ar' ? 'نتصلو بك للتأكيد قبل الإرسال' : 'On vous appelle pour confirmer' },
        ].map((item, i) => (
          <div key={i} className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex items-center gap-6 hover:shadow-md transition-shadow">
            <div className="p-4 bg-gray-50 rounded-2xl">{item.icon}</div>
            <div>
              <h3 className="font-bold text-lg">{item.title}</h3>
              <p className="text-gray-500 text-sm">{item.desc}</p>
            </div>
          </div>
        ))}
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold font-brand text-center mb-12">{t('categories')}</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
          {CATEGORIES.map(cat => (
            <Link
              to={`/shop?category=${cat.id}`}
              key={cat.id}
              className="group bg-white p-8 rounded-3xl border border-gray-100 text-center hover:bg-[#FDE2E4] transition-all hover:-translate-y-1 shadow-sm"
            >
              <span className="text-5xl block mb-4 transform group-hover:scale-110 transition-transform">{cat.icon}</span>
              <span className="font-bold text-gray-700">{lang === 'ar' ? cat.name : cat.nameFr}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Best Sellers */}
      <section className="bg-[#FAF3E0] py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold font-brand">{t('best_sellers')}</h2>
            <Link to="/shop" className="text-[#F08080] font-bold hover:underline">
              {lang === 'ar' ? 'عرض الكل' : 'Voir tout'}
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {PRODUCTS.slice(0, 4).map(product => (
              <div key={product.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all group">
                <div className="relative aspect-square">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute top-4 right-4 bg-red-500 text-white text-xs px-3 py-1 rounded-full font-bold">
                    {t('limited_stock')}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-bold text-lg mb-2">{lang === 'ar' ? product.name : product.nameFr}</h3>
                  <div className="flex items-center gap-1 mb-4">
                    {[1, 2, 3, 4, 5].map(s => <Star key={s} size={14} className="fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#F08080] font-bold text-xl">{product.price} {t('mad')}</span>
                    <Link
                      to={`/product/${product.id}`}
                      className="bg-[#E2E2FF] text-[#4A4E69] px-4 py-2 rounded-full text-sm font-bold hover:bg-[#F08080] hover:text-white transition-colors"
                    >
                      {lang === 'ar' ? 'التفاصيل' : 'Détails'}
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold font-brand text-center mb-12">{lang === 'ar' ? 'ماذا يقول الآباء' : 'Avis des parents'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: 'سارة من الدار البيضاء', text: 'صراحة التعامل معاهم جد راقي والسلعة جاتني كيفما شفتها فالتصاور. التوصيل كان سريع بزااف!' },
            { name: 'Youssef de Rabat', text: 'Service impeccable. J\'ai commandé un pack de couches et la livraison a été faite en 24h. Je recommande!' },
            { name: 'فاطمة من طنجة', text: 'الألعاب التعليمية لي شريت لولدي عجبوه بزاف وكولشي داز مزيان. شكرا بيبي لوكس.' },
          ].map((t, i) => (
            <div key={i} className="bg-white p-8 rounded-3xl border border-gray-50 shadow-sm italic text-gray-600 relative">
              <span className="absolute -top-4 right-8 text-6xl text-[#FDE2E4] font-serif">"</span>
              <p className="mb-6">{t.text}</p>
              <div className="font-bold not-italic text-[#F08080]">— {t.name}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
